% Declaration of a predicate for counting the number of printed lines.
:-dynamic collatzNr/1. 